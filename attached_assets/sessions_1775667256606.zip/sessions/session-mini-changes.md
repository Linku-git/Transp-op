# Session Mini-Changes — Docker Frontend Container & Chrome Testing

## Phase: Infrastructure / DX Improvement
## Prerequisites: [[sessions/session-03|Session 03]], [[sessions/session-05|Session 05]]

> This is a non-numbered maintenance session for developer experience improvements.

## Objective
Add the frontend dev container to Docker Compose so the full stack runs via `docker compose up`, and update agents/skills to use Google Chrome for visual testing, console output inspection, and full web app verification.

---

## Tasks

### Part 1 — Add Frontend Container to Docker Compose

- [x] Add `frontend` service to `docker-compose.yml`:
  - Image: `node:20-alpine` (Vite requires Node.js 20+)
  - Working dir: `/app`
  - Volumes: `./frontend:/app` + `frontend_node_modules:/app/node_modules`
  - Command: `npm run dev -- --host 0.0.0.0`
  - Port: `5173:5173`
  - Depends on: `backend` (service_healthy)
  - Healthcheck: `wget --spider http://127.0.0.1:5173 || exit 1`
  - Environment: `VITE_API_URL=http://localhost:8000/api/v1`
- [x] Add `frontend_node_modules` named volume to volumes section (avoids overwriting host node_modules)
- [x] Test: `docker compose up -d` — verify frontend is accessible at http://localhost:5173
- [ ] Test: frontend can reach backend API (no CORS issues from container)

### Part 2 — Update deploy-local Skill

- [x] Update `.claude/skills/deploy-local/SKILL.md`:
  - Add step to verify frontend container is healthy after `docker compose up -d`
  - Add `docker compose logs frontend --tail=20` to check for startup errors

### Part 3 — Update health-check Skill

- [x] Update `.claude/skills/health-check/SKILL.md`:
  - Add frontend container status check via `docker compose ps frontend`
  - Ensure frontend row in the status dashboard reflects Docker container status (not just curl)

### Part 4 — Add Chrome Testing to Agents & Skills

- [x] Update `.claude/skills/ui-review/SKILL.md`:
  - Add a "Live Browser Check" section after the static code audit
  - Instructions: open `http://localhost:5173` in Google Chrome, inspect console for errors/warnings, verify pages render correctly
  - Check console for: JS errors, React warnings, failed network requests, CORS errors
  - Check visual: page loads without blank screen, navigation works, no layout breakage

- [x] Update `.claude/skills/run-tests/SKILL.md`:
  - Add an optional `browser` scope/step:
    - Open `http://localhost:5173` in Google Chrome
    - Navigate to key pages (dashboard, sites, employees) and verify no console errors
    - Report: pages visited, console errors found, network failures

- [x] Update `agents.md` — add a new guideline under Section 5 (Code Quality Checklist) or as a new Section 11:
  - **Browser Verification Rule**: After any frontend session, open the app in Google Chrome to verify:
    1. No console errors or warnings
    2. Pages render correctly (no blank screens)
    3. API calls succeed (check Network tab)
    4. Navigation between pages works
  - Command reference: use `start chrome http://localhost:5173` (Windows) to launch Chrome

### Part 5 — Verification

- [x] Run `docker compose up -d` and confirm all services (db, redis, osrm, backend, frontend) are healthy
- [ ] Open http://localhost:5173 in Chrome — verify app loads
- [ ] Open Chrome DevTools Console — verify no errors
- [ ] Navigate to at least 3 pages — verify no runtime errors

---

## Files to Modify

| File | Change |
|------|--------|
| `docker-compose.yml` | Add `frontend` service + volume |
| `.claude/skills/deploy-local/SKILL.md` | Add frontend container verification steps |
| `.claude/skills/health-check/SKILL.md` | Add frontend Docker container check |
| `.claude/skills/ui-review/SKILL.md` | Add live Chrome browser check section |
| `.claude/skills/run-tests/SKILL.md` | Add optional browser test scope |
| `agents.md` | Add browser verification rule |

## Notes
- The frontend Dockerfile already exists (`frontend/Dockerfile`) but is production-oriented (nginx). The Docker Compose service should use the dev server (`npm run dev`) with hot reload.
- Vite is already configured with `host: true` in `vite.config.ts`, so it will accept connections from Docker's network.
- Chrome testing is manual/visual — this is not about adding Playwright/Cypress, just having agents open Chrome to visually verify and check console output.

### Deviations
- Changed `node:18-alpine` to `node:20-alpine` — Vite requires Node.js 20+
- Healthcheck uses `http://127.0.0.1:5173` instead of `http://localhost:5173` to avoid IPv6 resolution issues in Alpine
- Fixed backend healthcheck URL from `/health` to `/api/v1/health` (pre-existing bug)
- Added `npm install` to the frontend command (`sh -c "npm install && npm run dev -- --host 0.0.0.0"`) to install deps in the named volume on first run

## Test Results
- Tests written: 0 (infrastructure/docs session, no code tests)
- Tests passing: N/A
- Tests failing: N/A
- Docker verification: all 5 services healthy (db, redis, osrm, backend, frontend)
